sports_outdoors = {
    "Products": {
        "HotHands Hand Warmers 40 Pair Value Pack": {
            "Price": "$24.99 - $129.39",
            "Rating": "4.5",
            "Score": "899",
            "Total Reviews": "1,924",
            "Link": "https://www.amazon.com/HotHands-Hand-Warmers-Pair-Value/dp/B078T1X21B/"
        },
        "Band for Apple Watch Series 3 38mm 42mm, Yimzen Soft Silicone Replacement Sport Band iWatch Strap for Apple "
        "Watch Series 3 Series 2 Series 1, S/M M/L Size": {
            "Price": "$54",
            "Rating": "2.3",
            "Score": "323",
            "Total Reviews": "200",
            "Link": "https://www.amazon.com/Apple-Yimzen-Silicone-Replacement-iWatch/dp/B076N2GLFB/"
        }
    }
}
