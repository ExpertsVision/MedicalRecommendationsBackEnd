import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { getStyle, hexToRgba } from '@coreui/coreui/dist/js/coreui-utilities';
import { CustomTooltips } from '@coreui/coreui-plugin-chartjs-custom-tooltips';
import { HttpClient } from '@angular/common/http';
@Component({
  templateUrl: 'dashboard.component.html'
})
export class DashboardComponent implements OnInit {
  constructor(private httpClient: HttpClient) { }
  radioModel: string = 'Month';


  public lineChart3Legend = false;
  public lineChart3Type = 'line';


  // barChart1
  public barChart1Data: Array<any> = [
    {
      data: [],
      label: 'Series A'
    }
  ];

  public barChart1Options: any = {
    tooltips: {
      enabled: false,
      custom: CustomTooltips
    },
    maintainAspectRatio: false,
    scales: {
      xAxes: [{
        display: false,
        barPercentage: 0.6,
      }],
      yAxes: [{
        display: false
      }]
    },
    legend: {
      display: false
    }
  };
  public barChart1Colours: Array<any> = [
    {
      backgroundColor: 'rgba(255,255,255,.3)',
      borderWidth: 0
    }
  ];
  public barChart1Legend = false;
  public barChart1Type = 'bar';

  // mainChart

  public mainChartElements = 27;
  public mainChartData1: Array<number> = [];
  public mainChartData2: Array<number> = [];
  public mainChartData3: Array<number> = [];
  userTrafic=JSON;
  trafic_usage=[];
  public mainChartData: Array<any> = [
    {
      data: this.mainChartData1,
      label: 'Monthly User Trafic'
    }
  ];
  /* tslint:disable:max-line-length */
  public mainChartLabels: Array<any> = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday', 'Monday', 'Thursday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
  /* tslint:enable:max-line-length */
  public mainChartOptions: any = {
    tooltips: {
      enabled: false,
      custom: CustomTooltips,
      intersect: true,
      mode: 'index',
      position: 'nearest',
      callbacks: {
        labelColor: function(tooltipItem, chart) {
          return { backgroundColor: chart.data.datasets[tooltipItem.datasetIndex].borderColor };
        }
      }
    },
    responsive: true,
    maintainAspectRatio: false,
    scales: {
      xAxes: [{
        gridLines: {
          drawOnChartArea: false,
        },
        ticks: {
          callback: function(value: any) {
            return value.charAt(0);
          }
        }
      }],
      yAxes: [{
        ticks: {
          beginAtZero: true,
          maxTicksLimit: 5,
          stepSize: Math.ceil(250 / 5),
          max: 250
        }
      }]
    },
    elements: {
      line: {
        borderWidth: 2
      },
      point: {
        radius: 0,
        hitRadius: 10,
        hoverRadius: 4,
        hoverBorderWidth: 3,
      }
    },
    legend: {
      display: false
    }
  };
  public mainChartColours: Array<any> = [
    { // brandInfo
      backgroundColor: hexToRgba(getStyle('--info'), 10),
      borderColor: getStyle('--info'),
      pointHoverBackgroundColor: '#fff'
    },
    { // brandSuccess
      backgroundColor: 'transparent',
      borderColor: getStyle('--success'),
      pointHoverBackgroundColor: '#fff'
    },
    { // brandDanger
      backgroundColor: 'transparent',
      borderColor: getStyle('--danger'),
      pointHoverBackgroundColor: '#fff',
      borderWidth: 1,
      borderDash: [8, 5]
    }
  ];
  public mainChartLegend = false;
  public mainChartType = 'line';

  public brandBoxChartLabels: Array<any> = ['January', 'February', 'March', 'April', 'May', 'June', 'July'];
  public brandBoxChartOptions: any = {
    tooltips: {
      enabled: false,
      custom: CustomTooltips
    },
    responsive: true,
    maintainAspectRatio: false,
    scales: {
      xAxes: [{
        display: false,
      }],
      yAxes: [{
        display: false,
      }]
    },
    elements: {
      line: {
        borderWidth: 2
      },
      point: {
        radius: 0,
        hitRadius: 10,
        hoverRadius: 4,
        hoverBorderWidth: 3,
      }
    },
    legend: {
      display: false
    }
  };
  public brandBoxChartColours: Array<any> = [
    {
      backgroundColor: 'rgba(255,255,255,.1)',
      borderColor: 'rgba(255,255,255,.55)',
      pointHoverBackgroundColor: '#fff'
    }
  ];
  public brandBoxChartLegend = false;
  public brandBoxChartType = 'line';

  public random(min: number, max: number) {
    return Math.floor(Math.random() * (max - min + 1) + min);
  }

  // Doughnut
  public doughnutChartLabelsDrugs: string[];
  public doughnutChartLabelsRating: string[];
  public doughnutChartLabelsHashtags: string[];
  public doughnutChartData: number[];
  public doughnutChartData1=[];
  public doughnutChartData2: number[] = [1,1,1];
  public doughnutChartData3: number[] = [1,0,30,0,12,15,0,0,0,22];
  public doughnutChartType = 'doughnut';
public chartClicked(e:any):void {
console.log(e);
}

public chartHovered(e:any):void {
console.log(e);
}
drugsGraps=JSON;
public druglist=[];
public drugscount=[];
public drugsNames=[];
public hashTagscount=[];
public hashTagsNames=[];
hashtagsGraps=JSON;
hashtagslist=[];
ratingGraps=JSON;
ratinglist=[];
ratingNames=[];
ratingCount=[];
userTraficCount=[];

  ngOnInit(): void {

  this.httpClient.post('http://18.214.223.82:5000/user-traffic/', {"showresponses":1}).subscribe(data => {
    this.userTrafic = data as JSON;
    var k;
    //console.log(this.userTrafic['response']);

    this.userTraficCount.push(this.userTrafic['response']);
    for (k = 0; k < (this.userTraficCount).length; k++){
    this.trafic_usage.push(this.userTraficCount[k]);
    }
    console.log(this.trafic_usage[0].length);
    //this.mainChartData1=this.trafic_usage;
    //this.trafic_usage = this.mainChartData1[0];
    var x;
    for (x = 0; x < (this.trafic_usage[0]).length; x++){
    this.mainChartData1.push(this.trafic_usage[0][x]);
    }

    console.log(this.mainChartData1);
  })

  this.httpClient.post('http://18.214.223.82:5000/drug-graph/', {"showresponses":1}).subscribe(data => {
    this.drugsGraps = data as JSON;
    this.druglist.push(this.drugsGraps);
    var i;
    for (i = 0; i < this.druglist[0]['score'].length; i++) { 
    this.drugscount.push(this.druglist[0]['score'][i]);
    }
    var j;
    for (j = 0; j < this.druglist[0]['druglist'].length; j++) { 
    this.drugsNames.push(this.druglist[0]['druglist'][j]);
    }
    this.doughnutChartLabelsDrugs=this.drugsNames;
  
  })
  this.httpClient.post('http://18.214.223.82:5000/hashtag-graph/', {"showresponses":1}).subscribe(data => {
    this.hashtagsGraps = data as JSON;
    this.hashtagslist.push(this.hashtagsGraps);
    var l;
    for (l = 0; l < this.hashtagslist[0]['score'].length; l++) { 
    this.hashTagscount.push(this.hashtagslist[0]['score'][l]);
    }
    var m;
    for (m = 0; m < this.hashtagslist[0]['hashtag'].length; m++) { 
    this.hashTagsNames.push(this.hashtagslist[0]['hashtag'][m]);
    }
    this.doughnutChartLabelsHashtags=this.hashTagsNames;
  
  })

  this.httpClient.post('http://18.214.223.82:5000/rating-graph/', {"showresponses":1}).subscribe(data => {
    this.ratingGraps = data as JSON;
    this.ratinglist.push(this.ratingGraps);
    var n;
    for (n = 0; n < this.ratinglist[0]['score'].length; n++) { 
    this.ratingCount.push(this.ratinglist[0]['score'][n]);
    }
    var o;
    for (o = 0; o < this.ratinglist[0]['rating'].length; o++) { 
    this.ratingNames.push(this.ratinglist[0]['rating'][o]);
    }
    
  this.doughnutChartLabelsRating=this.ratingNames;
  })



  }
}
