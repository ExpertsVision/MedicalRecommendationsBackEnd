import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { getStyle, hexToRgba } from '@coreui/coreui/dist/js/coreui-utilities';
import { CustomTooltips } from '@coreui/coreui-plugin-chartjs-custom-tooltips';
import { HttpClient } from '@angular/common/http';
import { Chart } from 'chart.js';
import { Inject }  from '@angular/core';
import { DOCUMENT } from '@angular/common';

@Component({
  templateUrl: 'dashboard.component.html',
  styleUrls: ['dashboard.component.css']
})
export class DashboardComponent implements OnInit {
  
  selectedCategory="";
  response1="";
  response2="";
  all_responses_list=[];
  response_result=JSON;
  add_response_res=JSON;
  p:number;
  categories=[];
  all_categories=[];
  editCatName="";
  editPart1="";
  editPart2="";
  index:number;
  edit_response=JSON;
  getres=JSON;
  remove_dupli_cat=[];
  oldcatName="";
  oldPart1="";
  oldPart2="";
  constructor(private httpClient: HttpClient, @Inject(DOCUMENT) document) { }

  ngOnInit() {

    this.httpClient.post('http://127.0.0.1:5000/show-all-recommendations/', {"showresponses":1}).subscribe(data => {
    this.response_result = data as JSON;
    this.all_responses_list.push(this.response_result);
    console.log(this.response_result);
    console.log("yes it is working");
    console.log(this.all_responses_list[0][0]['Risk Factor Information']);
    //console.log(this.all_responses_list[0][0]);
    this.categories.push(this.response_result);
    var i;
    for (i = 0; i < this.all_responses_list[0].length; i++) { 
    console.log(this.all_responses_list[0][i]['Risk Factor Information']);}
    //this.all_categories.push(this.categories[0][i]['category']);}
    //let remove_duplicates_cat=Array.from(new Set(this.all_categories))
    //console.log(this.all_categories);
    //console.log(remove_duplicates_cat);
    //this.remove_dupli_cat=remove_duplicates_cat;
  
  })
 
  }

  addresponse(){
  this.httpClient.post('http://18.214.223.82:5000/add-response/', {"category":this.selectedCategory, "response1":this.response1,"response2":this.response2}).subscribe(data => {
    this.add_response_res = data as JSON;
    //alert(this.add_response_res);
    //this.res1=this.['response']
    alert(this.add_response_res['response']);
    }
  
  )
  
  }

  resetresponseval(){
    (<HTMLInputElement>document.getElementById("select1")).value='';
    (<HTMLInputElement>document.getElementById("text-response1")).value='';
    (<HTMLInputElement>document.getElementById("text-response2")).value='';
  }

  editSave(val1:string, val2:string, val3:string,val4:string,val5:string,val6:string,val7:string,val8:string,val9:string){
  
    this.editCatName=val1;
    this.editPart1=val2;
    this.editPart2=val3;
    console.log(val1,val2,val3,val4,val5,val6,val7,val8,val9);
    //this.httpClient.post('http:///edit-response/',{"category":this.editCatName,
    //"old_response1":this.oldPart1, "new_response1":this.editPart1,
    //"old_response2":this.oldPart2, "new_response2":this.editPart2}).subscribe(data => {
      //this.edit_response = data as JSON;
      //console.log(this.edit_response);
      //alert(this.edit_response['response']);
      
    //})
  }
delCatName="";
delPart1="";
delPart2="";
  deleteResponse(val1:string){
    
    this.delCatName=val1;
    this.httpClient.post('http://127.0.0.1:5000/delete-recomendations/',{"val":val1}).subscribe(data => {
      this.getres = data as JSON;
      //console.log(this.getres);
      alert(this.getres['response']);
      
    })
  }

  oldvalues(val:string, val2:string, val3:string){
  console.log(val);
  console.log(val2);
  console.log(val3);
  this.oldcatName=val;
  this.oldPart1=val2;
  this.oldPart2=val3;
  }



}

